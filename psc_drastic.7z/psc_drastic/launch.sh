#!/bin/sh
source "/var/volatile/bleemsync.cfg"
cd "/var/volatile/launchtmp"
chmod +x "drastic"
echo "launch_StockUI" > "/tmp/launchfilecommand"
LD_PRELOAD=./drastic_sdl_remap.so ./drastic > $runtime_log_path/drastic.log 2>&1
