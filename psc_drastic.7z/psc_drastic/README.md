**DraStic v2.5.0.4 for Playstation Classic (5/2019)**

Provided with many thanks by Exophase (exophase@gmail.com)

Please see drastic_readme.txt for full credits and changelogs

PSC Port by swingflip, CompCom, Wraith, andshrew

**Where to install**

Install entire psc_drastic folder to /media/bleemsync/etc/bleemsync/SUP/launchers

**Where do the BIOS Files go?**

The NDS BIOS files are not needed, except if you need to play encrypted roms. 

The optional NDS BIOS files should be installed in the following directory: 

/media/bleemsync/etc/bleemsync/SUP/launchers/psc_drastic/system

They must be named as follows:

* nds_bios_arm7.bin 
* nds_bios_arm9.bin 
* nds_firmware.bin
 

**Default Menu Controls**

* Circle/B - Select
* Cross/A - Back


**In-Game Menu Controls**

* L2 - Menu
